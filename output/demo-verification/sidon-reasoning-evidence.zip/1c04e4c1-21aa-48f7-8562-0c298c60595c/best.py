import math
import random

_S = 1 << 32


def _conv(a, b):
    la, lb = len(a), len(b)
    bits = max(a).bit_length() + max(b).bit_length() + min(la, lb).bit_length() + 1
    B = (bits + 7) // 8
    A = int.from_bytes(b''.join(v.to_bytes(B, 'little') for v in a), 'little')
    C = int.from_bytes(b''.join(v.to_bytes(B, 'little') for v in b), 'little')
    P = (A * C).to_bytes(B * (la + lb), 'little')
    return [int.from_bytes(P[i:i + B], 'little') for i in range(0, B * (la + lb - 1), B)]


def _optimize(x, iters, beta0, beta1, lr0):
    m = len(x)
    mo = [0.0] * m
    ve = [0.0] * m
    best_c, best_p = float('inf'), None
    for t in range(iters):
        q = [v * v for v in x]
        Q = sum(q) or 1.0
        p = [v / Q for v in q]
        pi = [int(v * _S) for v in p]
        if not any(pi):
            pi[0] = 1
        a = _conv(pi, pi)
        s = sum(pi)
        amax = max(a)
        c = 2 * m * amax / (s * s)
        if c < best_c:
            best_c, best_p = c, p
        beta = beta0 * (beta1 / beta0) ** (t / max(1, iters - 1))
        sc = beta * 2 * m / (s * s)
        w = [math.exp(sc * (ak - amax)) for ak in a]
        W = sum(w)
        wi = [int(v / W * _S) for v in w]
        if not any(wi):
            wi[a.index(amax)] = 1
        r = _conv(wi, pi[::-1])
        G = r[m - 1:2 * m - 1]
        gp = sum(G[i] * p[i] for i in range(m))
        g = [x[i] * (G[i] - gp) for i in range(m)]
        gm = max(abs(v) for v in g) or 1.0
        lr = lr0 * (0.05 + 0.95 * 0.5 * (1 + math.cos(math.pi * t / iters)))
        b1c = 1 - 0.9 ** (t + 1)
        b2c = 1 - 0.999 ** (t + 1)
        for i in range(m):
            gi = g[i] / gm
            mo[i] = 0.9 * mo[i] + 0.1 * gi
            ve[i] = 0.999 * ve[i] + 0.001 * gi * gi
            x[i] -= lr * (mo[i] / b1c) / (math.sqrt(ve[i] / b2c) + 1e-8)
        nrm = math.sqrt(sum(v * v for v in x) / m) or 1.0
        x = [v / nrm for v in x]
    return best_c, best_p


def _resample(p, m2):
    m = len(p)
    cum = [0.0]
    for v in p:
        cum.append(cum[-1] + v)

    def F(t):
        k = int(t)
        if k >= m:
            return cum[m]
        return cum[k] + (t - k) * p[k]

    mass = [F((j + 1) * m / m2) - F(j * m / m2) for j in range(m2)]
    tot = sum(mass) or 1.0
    return [math.sqrt(max(v / tot * m2, 1e-4)) for v in mass]


def _arcsine(m):
    return [(1.0 - ((2 * i + 1 - m) / m) ** 2) ** -0.25 for i in range(m)]


def solve(n: int) -> list[int]:
    sizes = []
    m = n
    while m > 48:
        sizes.append(m)
        m = (m + 1) // 2
    sizes.append(m)
    sizes.reverse()
    m0 = sizes[0]
    restarts = 8 if m0 > 8 else 4
    cands = []
    for r in range(restarts):
        rng = random.Random(7919 * r + 13)
        if r == 0:
            x = [1.0] * m0
            x[0] = x[-1] = 1.6
        elif r == 1:
            x = _arcsine(m0)
        elif r == 2:
            x = [v * rng.uniform(0.8, 1.2) for v in _arcsine(m0)]
        else:
            x = [rng.uniform(0.3, 1.5) for _ in range(m0)]
        c, p = _optimize(x, 2000, 20.0, 4000.0, 0.05)
        if p is not None:
            cands.append((c, p))
    cands.sort(key=lambda z: z[0])
    cands = cands[:2]
    for m in sizes[1:]:
        iters = min(1500, max(80, 200000 // m))
        nxt = []
        for _, p in cands:
            c, p2 = _optimize(_resample(p, m), iters, 300.0, 8000.0, 0.02)
            nxt.append((c, p2))
        nxt.sort(key=lambda z: z[0])
        cands = nxt[:2] if m < 256 else nxt[:1]
    best_c, p = cands[0]
    # High-temperature, low-noise polish at the target resolution.
    if len(p) == n:
        iters = min(1200, max(150, 400000 // n))
        x = [math.sqrt(max(v * n, 1e-6)) for v in p]
        c2, p2 = _optimize(x, iters, 3000.0, 60000.0, 0.004)
        if p2 is not None and c2 < best_c:
            best_c, p = c2, p2
    tot = sum(p)
    q = [int(v / tot * (1 << 40)) for v in p]
    if len(q) != n or sum(q) < (1 << 36):
        q = [1 << 36] * n
    return q
