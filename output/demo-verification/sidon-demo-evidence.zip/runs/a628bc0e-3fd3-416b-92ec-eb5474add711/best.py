import math


def solve(n: int) -> list[int]:
    """
    Minimize c1 = 2*n*max(a) / (sum(q))^2
    where a[k] = sum_{i} q[i]*q[k-i] is the discrete autoconvolution.

    Strategy:
    1. Initialize with a raised cosine (Hann window) shape
    2. Run incremental coordinate-descent to reduce c1
    3. Ensure feasibility (integral^2 >= 1e-8)
    """
    SCALE = 1 << 20  # internal working scale

    def compute_conv(q):
        a = [0] * (2 * n - 1)
        for i in range(n):
            if q[i] == 0:
                continue
            for j in range(n):
                if q[j] == 0:
                    continue
                a[i + j] += q[i] * q[j]
        return a

    def compute_c1_from_conv(a, s):
        if s == 0:
            return float('inf')
        return 2 * n * max(a) / (s * s)

    def hann_init():
        qq = [0] * n
        for i in range(n):
            if n > 1:
                t = math.pi * (2 * i / (n - 1) - 1)
            else:
                t = 0.0
            val = (1.0 + math.cos(t)) / 2.0
            qq[i] = max(0, int(val * SCALE))
        return qq

    def gaussian_init(sigma_frac=0.3):
        qq = [0] * n
        mid = (n - 1) / 2.0
        sigma = max(sigma_frac * n, 1.0)
        for i in range(n):
            val = math.exp(-0.5 * ((i - mid) / sigma) ** 2)
            qq[i] = max(0, int(val * SCALE))
        return qq

    def triangle_init():
        qq = [0] * n
        mid = (n - 1) / 2.0
        for i in range(n):
            val = 1.0 - abs(i - mid) / max(mid, 1.0)
            qq[i] = max(0, int(val * SCALE))
        return qq

    def uniform_init():
        return [SCALE] * n

    # Budget parameters based on n
    if n <= 32:
        inits = [hann_init(), gaussian_init(0.25), gaussian_init(0.4), triangle_init(), uniform_init()]
        max_steps = 200
        max_coords = n
    elif n <= 128:
        inits = [hann_init(), gaussian_init(0.3), triangle_init(), uniform_init()]
        max_steps = 60
        max_coords = n
    elif n <= 512:
        inits = [hann_init(), gaussian_init(0.3), uniform_init()]
        max_steps = 15
        max_coords = min(n, 80)
    elif n <= 1024:
        inits = [hann_init(), uniform_init()]
        max_steps = 8
        max_coords = min(n, 50)
    else:
        inits = [hann_init()]
        max_steps = 4
        max_coords = min(n, 30)

    def incremental_search(qq, steps, max_c):
        a = compute_conv(qq)
        s = sum(qq)
        if s == 0:
            return qq, float('inf')
        cur_c1 = compute_c1_from_conv(a, s)

        step_size = SCALE // 4

        for _step in range(steps):
            improved = False
            # Only scan a subset of indices per iteration
            # Focus on evenly spaced indices to cover the shape
            if max_c >= n:
                indices = list(range(n))
            else:
                # Sample evenly spaced indices
                indices = [int(i * n / max_c) for i in range(max_c)]

            for idx in indices:
                old_val = qq[idx]

                # Try both directions with current step size
                best_delta = 0
                best_new_c1 = cur_c1

                for delta in [step_size, -step_size]:
                    new_val = old_val + delta
                    if new_val < 0:
                        continue
                    new_s = s - old_val + new_val
                    if new_s <= 0:
                        continue

                    # Compute updated max of autoconvolution incrementally
                    # Changing q[idx] by delta:
                    # a[k] changes for k in [idx, idx+n-1] (where k-idx in [0,n-1])
                    # Change: if k-idx == idx (k=2*idx): delta*(2*old_val+delta)
                    #         else: 2*delta*qq[k-idx]
                    new_max_a = 0
                    for k in range(2 * n - 1):
                        j = k - idx
                        if 0 <= j < n:
                            if j == idx:
                                new_ak = a[k] + delta * (2 * old_val + delta)
                            else:
                                new_ak = a[k] + 2 * delta * qq[j]
                        else:
                            new_ak = a[k]
                        if new_ak > new_max_a:
                            new_max_a = new_ak

                    if new_max_a < 0:
                        continue
                    new_c1 = 2 * n * new_max_a / (new_s * new_s)
                    if new_c1 < best_new_c1:
                        best_new_c1 = new_c1
                        best_delta = delta

                if best_delta != 0:
                    delta = best_delta
                    new_val = old_val + delta
                    new_s = s - old_val + new_val
                    # Apply update to convolution array
                    for k in range(2 * n - 1):
                        j = k - idx
                        if 0 <= j < n:
                            if j == idx:
                                a[k] += delta * (2 * old_val + delta)
                            else:
                                a[k] += 2 * delta * qq[j]
                    qq[idx] = new_val
                    s = new_s
                    cur_c1 = best_new_c1
                    improved = True

            if not improved:
                # Halve step size and retry
                step_size = step_size // 2
                if step_size < 1:
                    break

        return qq, cur_c1

    best_q = None
    best_c1 = float('inf')

    for init_q in inits:
        if sum(init_q) == 0:
            init_q = [1] * n
        qq, c = incremental_search(init_q[:], max_steps, max_coords)
        if c < best_c1:
            best_c1 = c
            best_q = qq[:]

    if best_q is None or sum(best_q) == 0:
        best_q = [SCALE] * n

    # Ensure feasibility: integral = sum(q) / (2*n * 2^40) >= 1e-4
    # so integral^2 >= 1e-8
    scale_40 = 1 << 40
    min_sum_needed = math.ceil(1e-4 * 2 * n * scale_40)
    current_sum = sum(best_q)
    if current_sum < min_sum_needed:
        factor = math.ceil(min_sum_needed / current_sum)
        best_q = [x * factor for x in best_q]

    if sum(best_q) == 0:
        best_q = [SCALE] * n

    return best_q
