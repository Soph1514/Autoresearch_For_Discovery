import math


def solve(n: int) -> list[int]:
    """
    Minimize c1 = 2*n*max(a) / (sum(q))^2
    where a[k] = sum_{i} q[i]*q[k-i] is the discrete autoconvolution.

    Strategy:
    1. Initialize with multiple shapes (Hann, Gaussian variants, triangle, uniform)
    2. Run incremental coordinate-descent with smarter step-size and index ordering
    3. Ensure feasibility (integral^2 >= 1e-8)
    """
    SCALE = 1 << 20  # internal working scale

    def compute_conv(q):
        a = [0] * (2 * n - 1)
        for i in range(n):
            if q[i] == 0:
                continue
            for j in range(n):
                if q[j] == 0:
                    continue
                a[i + j] += q[i] * q[j]
        return a

    def compute_c1_from_conv(a, s):
        if s == 0:
            return float('inf')
        return 2 * n * max(a) / (s * s)

    def hann_init():
        qq = [0] * n
        for i in range(n):
            if n > 1:
                t = math.pi * (2 * i / (n - 1) - 1)
            else:
                t = 0.0
            val = (1.0 + math.cos(t)) / 2.0
            qq[i] = max(0, int(val * SCALE))
        return qq

    def gaussian_init(sigma_frac=0.3):
        qq = [0] * n
        mid = (n - 1) / 2.0
        sigma = max(sigma_frac * n, 1.0)
        for i in range(n):
            val = math.exp(-0.5 * ((i - mid) / sigma) ** 2)
            qq[i] = max(0, int(val * SCALE))
        return qq

    def triangle_init():
        qq = [0] * n
        mid = (n - 1) / 2.0
        for i in range(n):
            val = 1.0 - abs(i - mid) / max(mid, 1.0)
            qq[i] = max(0, int(val * SCALE))
        return qq

    def uniform_init():
        return [SCALE] * n

    def raised_cosine_init(alpha=0.5):
        """Raised cosine with tunable roll-off alpha."""
        qq = [0] * n
        mid = (n - 1) / 2.0
        for i in range(n):
            t = (i - mid) / max(mid, 1.0)  # t in [-1, 1]
            val = 0.5 * (1.0 + math.cos(math.pi * t))
            qq[i] = max(0, int(val ** alpha * SCALE))
        return qq

    # Budget parameters based on n
    if n <= 32:
        inits = [hann_init(), gaussian_init(0.25), gaussian_init(0.4),
                 triangle_init(), uniform_init(), raised_cosine_init(0.7)]
        max_steps = 300
        max_coords = n
    elif n <= 128:
        inits = [hann_init(), gaussian_init(0.3), triangle_init(),
                 uniform_init(), raised_cosine_init(0.6)]
        max_steps = 80
        max_coords = n
    elif n <= 512:
        inits = [hann_init(), gaussian_init(0.3), uniform_init(),
                 raised_cosine_init(0.6)]
        max_steps = 18
        max_coords = min(n, 100)
    elif n <= 1024:
        inits = [hann_init(), uniform_init(), raised_cosine_init(0.6)]
        max_steps = 10
        max_coords = min(n, 60)
    else:
        inits = [hann_init(), raised_cosine_init(0.6)]
        max_steps = 5
        max_coords = min(n, 40)

    def incremental_search(qq, steps, max_c):
        a = compute_conv(qq)
        s = sum(qq)
        if s == 0:
            return qq, float('inf')
        cur_c1 = compute_c1_from_conv(a, s)

        # Start with a larger step size and decay more slowly
        step_size = SCALE // 2

        for _step in range(steps):
            improved = False

            # Find current peak position in convolution to guide scanning
            max_a_val = max(a)
            peak_k = a.index(max_a_val)

            # Build index scan order: prioritize indices that contribute to peak
            # Indices i such that peak_k - i is also in [0, n-1]
            # i.e., peak_k - (n-1) <= i <= peak_k, intersected with [0, n-1]
            lo = max(0, peak_k - (n - 1))
            hi = min(n - 1, peak_k)
            peak_contributors = list(range(lo, hi + 1))

            if max_c >= n:
                # Full scan: peak contributors first, then rest
                rest = [i for i in range(n) if i < lo or i > hi]
                indices = peak_contributors + rest
            else:
                # Partial scan: evenly spaced but weighted toward peak region
                # Take half from peak contributors, half evenly spaced
                half = max_c // 2
                # Peak contributor sample
                if len(peak_contributors) <= half:
                    peak_sample = peak_contributors
                else:
                    step_pc = max(1, len(peak_contributors) // half)
                    peak_sample = peak_contributors[::step_pc][:half]
                # Even spacing for the rest
                remaining = max_c - len(peak_sample)
                if remaining > 0:
                    even_sample = [int(i * n / remaining) for i in range(remaining)]
                    # Remove duplicates with peak_sample
                    peak_set = set(peak_sample)
                    even_sample = [i for i in even_sample if i not in peak_set]
                else:
                    even_sample = []
                indices = peak_sample + even_sample

            for idx in indices:
                old_val = qq[idx]

                best_delta = 0
                best_new_c1 = cur_c1

                for delta in [step_size, -step_size]:
                    new_val = old_val + delta
                    if new_val < 0:
                        continue
                    new_s = s - old_val + new_val
                    if new_s <= 0:
                        continue

                    # Compute updated max of autoconvolution incrementally
                    new_max_a = 0
                    for k in range(2 * n - 1):
                        j = k - idx
                        if 0 <= j < n:
                            if j == idx:
                                new_ak = a[k] + delta * (2 * old_val + delta)
                            else:
                                new_ak = a[k] + 2 * delta * qq[j]
                        else:
                            new_ak = a[k]
                        if new_ak > new_max_a:
                            new_max_a = new_ak

                    if new_max_a < 0:
                        continue
                    new_c1 = 2 * n * new_max_a / (new_s * new_s)
                    if new_c1 < best_new_c1:
                        best_new_c1 = new_c1
                        best_delta = delta

                if best_delta != 0:
                    delta = best_delta
                    new_val = old_val + delta
                    new_s = s - old_val + new_val
                    # Apply update to convolution array
                    for k in range(2 * n - 1):
                        j = k - idx
                        if 0 <= j < n:
                            if j == idx:
                                a[k] += delta * (2 * old_val + delta)
                            else:
                                a[k] += 2 * delta * qq[j]
                    qq[idx] = new_val
                    s = new_s
                    cur_c1 = best_new_c1
                    improved = True

            if not improved:
                # Halve step size and retry (slower decay: need 2 failures before halving)
                step_size = step_size * 3 // 4
                if step_size < 1:
                    break

        return qq, cur_c1

    best_q = None
    best_c1 = float('inf')

    for init_q in inits:
        if sum(init_q) == 0:
            init_q = [1] * n
        qq, c = incremental_search(init_q[:], max_steps, max_coords)
        if c < best_c1:
            best_c1 = c
            best_q = qq[:]

    if best_q is None or sum(best_q) == 0:
        best_q = [SCALE] * n

    # Ensure feasibility: integral = sum(q) / (2*n * 2^40) >= 1e-4
    # so integral^2 >= 1e-8
    scale_40 = 1 << 40
    min_sum_needed = math.ceil(1e-4 * 2 * n * scale_40)
    current_sum = sum(best_q)
    if current_sum < min_sum_needed:
        factor = math.ceil(min_sum_needed / current_sum)
        best_q = [x * factor for x in best_q]

    if sum(best_q) == 0:
        best_q = [SCALE] * n

    return best_q
