def solve(initial: list[int]) -> list[int]:
    return list(initial)
